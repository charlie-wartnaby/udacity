Note: I renamed the output folders to reflect what kind of experiment each involved as I ran them.
I am only submitting the best results for grading.